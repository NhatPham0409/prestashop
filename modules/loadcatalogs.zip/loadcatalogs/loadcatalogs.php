<?php

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
use Symfony\Component\HttpClient\HttpClient;

if (!defined('_PS_VERSION_')) {
    exit;
}

class LoadCatalogs extends Module implements WidgetInterface
{
    private $templateFile;

    public function __construct()
    {
        $this->name = 'loadcatalogs';
        $this->tab = 'front_office_features';
        $this->author = 'Cong Danh';
        $this->version = '1.0.0';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7.7.0', 'max' => _PS_VERSION_];
        $this->bootstrap = true;

        parent::__construct();
        $this->displayName = $this->trans('Load Catalogs', [], 'Modules.LoadCatalogs.Admin');
        $this->description = $this->trans('Load catalogs from web to database', [], 'Modules.LoadCatalogs.Admin');
        $this->confirmUninstall = $this->trans('Are you sure you want to uninstall?', [], 'Modules.LoadCatalogs.Admin');

        if (!Configuration::get('LOADCATALOGS')) {
            $this->warning = $this->trans('No name provided', [], 'Modules.LoadCatalogs.Admin');
        }
        $this->templateFile = 'module:loadcatalogs/views/templates/hook/loadcatalogs.tpl';
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return (
            parent::install()
            && Configuration::updateValue('LOADCATALOGS', 'Cong Danh first module configuration')
            && $this->registerHook('displayHome')
        );
    }

    public function uninstall()
    {
        return (
            parent::uninstall()
            && Configuration::deleteByName('LOADCATALOGS')
        );
    }

    public function getContent()
    {
        $output = '';

        if (Tools::isSubmit('btnSubmit')) {
            $link = null;
            if (Tools::isSubmit('LINK')) {
                $link = Tools::getValue('LINK');
            }
            if ($link == null) {
                $output = $this->displayError($this->l('Invalid link'));
            } else {
                $this->fetchDataFromAPI($link);
                $output = $this->displayConfirmation($this->l('Sync successfull!'));
            }
        }
        return $this->renderForm();
    }


    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitManageCategoryModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => 'abc', /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                'title' => $this->l('Manage Category'),
                'icon' => 'icon-cogs',
                ),
                'input' => array(
//                    array(
//                        'type' => 'switch',
//                        'label' => $this->l('Live mode'),
//                        'name' => 'MANAGECATEGORY_LIVE_MODE',
//                        'is_bool' => true,
//                        'desc' => $this->l('Use this module in live mode'),
//                        'values' => array(
//                            array(
//                                'id' => 'active_on',
//                                'value' => true,
//                                'label' => $this->l('Enabled')
//                            ),
//                            array(
//                                'id' => 'active_off',
//                                'value' => false,
//                                'label' => $this->l('Disabled')
//                            )
//                        ),
//                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-text-height"></i>',
                        'desc' => $this->l('Enter your json value here'),
                        'name' => 'MANAGECATEGORY_JSON',
                        'label' => $this->l('JSON'),
                    ),
//                    array(
//                        'type' => 'password',
//                        'name' => 'MANAGECATEGORY_ACCOUNT_PASSWORD',
//                        'label' => $this->l('Password'),
//                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Sync data'),
                ),
            ),
        );
    }
    /**
     * Builds the configuration form
     * @return string HTML code
     */
    public function displayForm()
    {
        // Init Fields form array
        // $form = [
        //     'form' => [
        //         'legend' => [
        //             'title' => $this->l('Configuration'),
        //         ],
        //         'input' => array(
        //             // array(
        //             //     'type' => 'text',
        //             //     'label' => $this->l('Link'),
        //             //     'name' => 'LINK',
        //             //     'size' => 20,
        //             //     'required' => true,
        //             // ),
        //             array(
        //                 'name' => "GIANGNAM",
        //                 'type' => 'text',
        //             )
        //         ),
        //         'submit' => [
        //             'title' => $this->l('Sync'),
        //             'class' => 'btn btn-default pull-right',
        //         ],
        //     ],
        // ];
        $helper = new HelperForm();
        $form = [
            [
                'form' => [
                    'legend' => [       
                        'title' => $this->l('Edit carrier'),       
                        'icon' => 'icon-cogs'   
                    ],   
                    'input' => [       
                        [           
                            'type' => 'text',
                            'name' => 'shipping_method',
                        ],
                    ],
                    'submit' => [
                        'title' => $this->l('Save'),       
                        'class' => 'btn btn-default pull-right'   
                    ],
                ],
            ],
        ];

        // Module, token and currentIndex
        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);
        $helper->submit_action = 'btnSubmit';
        // Default language
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');

        return $helper->generateForm($form);
        // return $helper->generateForm([$form]);
    }

    public function renderWidget($hookName, array $configuration)
    {
        dump(Category::getCategories());
        // dump($this->fetchDataFromAPI());
        // if (!$this->isCached($this->templateFile, $this->getCacheId('loadmovies'))) {
        //     $variables = $this->getWidgetVariables($hookName, $configuration);

        //     if (empty($variables)) {
        //         return false;
        //     }
        //     $this->smarty->assign('products', $variables); // Assign data to the template file
        // }
        return $this->fetch($this->templateFile);
    }

    public function getWidgetVariables($hookName, array $configuration)
    {
        // $query = new DbQuery();
        // $movies = $query
        //     ->select('imdb_id', 'title', 'image', 'rating_star', 'release_year')
        //     ->from(self::TABLE_MOVIES)
        //     ->orderBy('imdb_id', 'ASC');
        // $movies = Db::getInstance()->executeS($movies);
        // $products = [];
        // if (!empty($movies)) {
        //     foreach ($movies as $movie) {
        //         $products[] = array(
        //             'id' => $movie['imdb_id'],
        //             'title' => $movie['title'],
        //             'image' => $movie['image'],
        //             'rating_star' => $movie['rating_star'],
        //             'release_year' => $movie['release_year'],
        //         );
        //     }
        // }
        return null;
    }

    public function fetchDataFromAPI($apiUrl)
    {
        // $apiUrl = 'https://mocki.io/v1/442ee681-3dd7-4047-8034-faff7c47f023';

        // Create a Symfony HttpClient instance
        $httpClient = HttpClient::create();
        try {
            $response = $httpClient->request('GET', $apiUrl);
            $statusCode = $response->getStatusCode();

            if ($statusCode != 200) {
                return 'Failed to fetch movie data from API';
            }

            $content = $response->getContent();
            $content = $response->toArray();

            $this->insertDataIntoDatabase($content);
            return 'success';
            // return $content;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    // "name" => "Clothes"
    // "description" => "<p>Discover our favorites fashionable discoveries, a selection of cool items to integrate in your wardrobe. Compose a unique style with personality which matche ▶"
    // "additional_description" => ""
    // "link_rewrite" => "clothes"
    // "meta_title" => ""
    // "meta_keywords" => ""
    // "meta_description" => ""
    public function insertDataIntoDatabase($datas, $idParent = 2)
    {
        foreach ($datas as $data) {
            $category = new Category();
            $category->name = $data['name'];
            $category->id_parent = $idParent;
            $category->groupBox = [1, 2, 3];
            $category->description = "<p>Nothing</p>";
            $category->link_rewrite = strtolower($data['name']);
            $category->meta_title = "";
            $category->meta_keywords = "";
            $category->meta_description = "";
            $category->additional_description = "";
            $category->doNotRegenerateNTree = false;
            $category->add();
        }
    }
    public function deleteDataFromDatabase($idCategory)
    {
        $category = new Category();
        $category->id = $idCategory;
        $category->delete();
    }
}
