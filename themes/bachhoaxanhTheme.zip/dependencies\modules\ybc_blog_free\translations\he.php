<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>blog_list_222100df7fee41afa5d39aef8337a562'] = 'מְחַבֵּר:';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'תגובות';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_16_222100df7fee41afa5d39aef8337a562'] = 'מְחַבֵּר:';
$_MODULE['<{ybc_blog_free}prestashop>categories_block_3cfd94e5b1e020a2b88c15f49d57886e'] = 'קטגוריות';
