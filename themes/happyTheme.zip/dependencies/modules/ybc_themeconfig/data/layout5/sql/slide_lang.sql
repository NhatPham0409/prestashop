INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('11','_ID_LANG_','New lap top Serires','<p>New laptop model from Acer, powerful notebook for<br /> anywhere the jobs take you</p>','Acer Aspire R11','Purchase now','#','9d461b9fb35598159114cc3784b13d7f3e0b83f9_slider5.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('16','_ID_LANG_','New Smart watch series','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br /> odio. Praesent libero. Sed cursus ante dapibus diam</p>','Apple watches','Purchase now','#','1f788c8e21c0c47ee969bb4ce8e7ae3e4f2f760b_slider5-2.jpg');


