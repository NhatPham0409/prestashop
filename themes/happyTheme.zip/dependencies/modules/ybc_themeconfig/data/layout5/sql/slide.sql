INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('11','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('16','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('11','0','1','random','10%','10%','10%','type1','left','left','60%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('16','0','1','random','10%','10%','10%','type2','left','left','60%','','#');


