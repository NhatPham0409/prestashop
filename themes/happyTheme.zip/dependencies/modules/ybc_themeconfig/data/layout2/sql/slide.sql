INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('3','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('13','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('3','0','1','random','8%','1px','1%','type2','left','left','70%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('13','0','1','random','10%','1px','1px','type2','left','left','70%','','#');


