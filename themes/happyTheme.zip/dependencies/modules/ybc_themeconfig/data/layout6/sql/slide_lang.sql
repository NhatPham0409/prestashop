INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('12','_ID_LANG_','20% off for all products','<p>Lorem ipsum dolor sit amet, consectetur<br /> elit. Integer nec odio.</p>','HTC ONE X','Purchase Now','#','4f51bedece43c915fab6774c54a800273d250f1a_slider-6.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('17','_ID_LANG_','New Samgsung tv','<p>Lorem ipsum dolor sit amet, consec<br /> tetur adipiscing elit. Integer</p>','curved tv','Purchase now','#','3e431cd65c707ab42089075f55d9296bc23d74af_slider6-2.jpg');


