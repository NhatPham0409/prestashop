INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('14','_ID_LANG_','Top navigation','','<ul>
<li><a href=\"http://demo.etssoft.net/digital/en/\">Home</a></li>
<li><a href=\"http://demo.etssoft.net/digital/content/4-about-us\">About Us</a></li>
<li><a href=\"#\">Company News</a></li>
<li><a href=\"#\">Careers</a></li>
<li><a href=\"http://demo.etssoft.net/digital/en/blog\">Blog</a></li>
<li><a href=\"http://demo.etssoft.net/digital/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout1\">Contact</a>
<ul>
<li><a href=\"http://demo.etssoft.net/digital/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout1\">Contact 1</a></li>
<li><a href=\"http://demo.etssoft.net/digital/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout2\">Contact 2</a></li>
<li><a href=\"http://demo.etssoft.net/digital/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout3\">Contact 3</a></li>
</ul>
</li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('47','_ID_LANG_','100% Brand new Guarantee','','<p>100% Brand new<br />Guarantee</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('48','_ID_LANG_','Excellent Warranty services','','<p>Excellent<br /> Warranty services</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('49','_ID_LANG_','Free shipping Within 50km','','<p>Free shipping<br /> Within 50km</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('50','_ID_LANG_','Dell Inspiron','-25% OFF','<p>Signature<br /> Edition Laptop</p>
<p><a class=\"bt_color\" href=\"#\">Purchase Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('51','_ID_LANG_','HTC phones','-10% OFF','<p>All brand new<br />products ready for sale</p>
<p><a href=\"#\" class=\"bt_color\">Purchase Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('52','_ID_LANG_','canon cameras','-20% OFF','<p>New arrivals coming<br />with best deals</p>
<p><a href=\"#\" class=\"bt_color\">Purchase Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('53','_ID_LANG_','Dell Vostro 1210','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh</p>
<p><a href=\"#\" class=\"bt_color\">Purchase Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('54','_ID_LANG_','Samsung phone  New arrivals','Sale off all products','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('55','_ID_LANG_','California','','<p>Address: Puffin street 12345 Puffinville <br /> Phone: (123) 4567889<br /> Opening hours: 8:00 to 21:00 (all days)</p>
<p><a href=\"#\" class=\"bt_color\">View on map</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('56','_ID_LANG_','Arizona','','<p>Address: Puffin street 12345 Puffinville <br /> Phone: (123) 4567889<br /> Opening hours: 8:00 to 21:00 (all days)</p>
<p><a href=\"#\" class=\"bt_color\">View on map </a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('57','_ID_LANG_','Michigan','','<p>Address: Puffin street 12345 Puffinville <br /> Phone: (123) 4567889<br /> Opening hours: 8:00 to 21:00 (all days)</p>
<p><a href=\"#\" class=\"bt_color\">View on map</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('58','_ID_LANG_','Washington','','<p>Address: Puffin street 12345 Puffinville <br /> Phone: (123) 4567889<br /> Opening hours: 8:00 to 21:00 (all days)</p>
<p><a href=\"#\" class=\"bt_color\">View on map</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('59','_ID_LANG_','Texas','','<p>Address: Puffin street 12345 Puffinville <br /> Phone: (123) 4567889<br /> Opening hours: 8:00 to 21:00 (all days)</p>
<p><a href=\"#\" class=\"bt_color\">View on map</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('60','_ID_LANG_','Oregon','','<p>Address: Puffin street 12345 Puffinville <br /> Phone: (123) 4567889<br /> Opening hours: 8:00 to 21:00 (all days)</p>
<p><a href=\"#\" class=\"bt_color\">View on map</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('61','_ID_LANG_','About us','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('62','_ID_LANG_','Contact Us','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('63','_ID_LANG_','Delivery','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('64','_ID_LANG_','Privacy','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('67','_ID_LANG_','Samsung tables','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('68','_ID_LANG_','accer','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('69','_ID_LANG_','Wifi cameras','-15% off','<p>Safety measure for <br />your house</p>');


