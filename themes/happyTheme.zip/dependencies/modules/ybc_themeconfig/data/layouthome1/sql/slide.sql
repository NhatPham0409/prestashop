INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','0','0','random','7%','310px','10%','type2','left','left','50%','','#');


