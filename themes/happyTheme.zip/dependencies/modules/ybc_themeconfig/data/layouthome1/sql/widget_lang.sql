INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('14','_ID_LANG_','Top navigation','','<ul>
<li><a href=\"http://demo.etssoft.net/ebusinessdemo/en/content/4-about-us\">About Us</a></li>
<li><a href=\"http://demo.etssoft.net/ebusinessdemo/en/content/6-customer-care\">Customer Care</a></li>
<li><a href=\"http://demo.etssoft.net/ebusinessdemo/en/content/7-careers\">Careers</a></li>
<li><a href=\"http://demo.etssoft.net/ebusinessdemo/en/contact-us\">Contact</a>
<ul>
<li><a href=\"http://demo.etssoft.net/ebusinessdemo/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=contact_layout1\">Contact page 1</a></li>
<li><a href=\"http://demo.etssoft.net/ebusinessdemo/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=contact_layout2\">Contact page 2</a></li>
<li><a href=\"http://demo.etssoft.net/ebusinessdemo/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=contact_layout3\">Contact page 3</a></li>
</ul>
</li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('47','_ID_LANG_','100% Brand new Guarantee','','<p>100% Brand new<br />Guarantee</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('48','_ID_LANG_','Excellent Warranty services','','<p>Excellent<br /> Warranty services</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('49','_ID_LANG_','Free shipping Within 50km','','<p>Free shipping<br /> Within 50km</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('51','_ID_LANG_','Women’s','','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('52','_ID_LANG_','Men’s shoes','','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('62','_ID_LANG_','Contact Us','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('63','_ID_LANG_','Delivery','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('64','_ID_LANG_','Privacy','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('69','_ID_LANG_','Sport fashion','','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('70','_ID_LANG_','Free shipping','','<p>Lorem ipsum dolor sit amet, consec adipiscing elit. Integer nec odi. Odio ent taciti sociosqu ad litora to</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('71','_ID_LANG_','24/7 online support','','<p>Lorem ipsum dolor sit amet, consec adipiscing elit. Integer nec odi. Odio ent taciti sociosqu ad litora to</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('72','_ID_LANG_','Secure payment','','<p>Lorem ipsum dolor sit amet, consec adipiscing elit. Integer nec odi. Odio ent taciti sociosqu ad litora to</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('73','_ID_LANG_','Sale','','');


