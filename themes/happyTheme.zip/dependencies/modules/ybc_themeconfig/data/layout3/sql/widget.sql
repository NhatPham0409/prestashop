INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('14','ybcCustom4','1','0','1','1','','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('47','ybcCustom2','1','0','1','1','','fa-tags','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('48','ybcCustom2','1','0','1','1','','fa-wrench','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('49','ybcCustom2','1','0','1','1','','fa-truck','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('50','ybcCustom5','1','1','1','1','top1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('51','ybcCustom5','1','1','1','1','top2.jpg','','#','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('52','ybcCustom5','1','1','1','1','top3.jpg','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('53','ybcCustom1','1','1','1','1','home1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('54','ybcCustom3','1','1','1','1','home2.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('55','displayFooter','1','1','1','1','','','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('56','displayFooter','1','1','1','1','','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('57','displayFooter','1','1','1','1','','','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('58','displayFooter','1','1','1','1','','','','6');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('59','displayFooter','1','1','1','1','','','','5');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('60','displayFooter','1','1','1','1','','','','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('61','ybcCustom6','1','1','1','1','','','http://demo.etssoft.net/digital/content/4-about-us','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('62','ybcCustom6','1','1','1','1','','','http://demo.etssoft.net/digital/contact-us','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('63','ybcCustom6','1','1','1','1','','','http://demo.etssoft.net/digital/content/1-delivery','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('64','ybcCustom6','1','1','1','1','','','#','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('69','ybcCustom5','1','1','1','1','buddy-cameras-2.jpg','','#','4');


