INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('9','_ID_LANG_','New generation of cctv cameras','<p>Keep safety for your house while travalling <br /> anywhere</p>','cctv cameras','Purchase now','#','bcd07649ce7529cce85367d809be2533442ea8da_slider-3.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('14','_ID_LANG_','20% off for all products','<p>Lorem ipsum dolor sit amet, consectetur adipiscing<br /> elit. Integer nec odio.</p>','HTC ONE X','Purchase now','#','8b6c8a093c8e678e14a4ad7a36acac68f3833c74_slider3-2.jpg');


