INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('9','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('14','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('9','0','1','random','10%','10%','10%','type1','left','left','40%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('14','0','1','random','10%','10%','10%','type3','left','left','60%','','#');


