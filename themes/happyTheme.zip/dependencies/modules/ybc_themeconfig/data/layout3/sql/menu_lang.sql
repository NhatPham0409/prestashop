INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('2','_ID_LANG_','Television');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('4','_ID_LANG_','Phones');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('5','_ID_LANG_','Contact');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('8','_ID_LANG_','Blog');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('10','_ID_LANG_','PC computers');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('11','_ID_LANG_','Laptops');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('12','_ID_LANG_','Cameras & lenses');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('13','_ID_LANG_','Electronics');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('14','_ID_LANG_','Apples');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('15','_ID_LANG_','Smart Watches');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('16','_ID_LANG_','Accessories');


INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('4','_ID_LANG_','','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('5','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('9','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('11','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('13','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('15','_ID_LANG_','Hot deals','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('16','_ID_LANG_','list product','','');


INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('6','_ID_LANG_','SAMSUNG','<ul><li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Vivamus porta</a></li>
<li><a href=\"#\">Sed faucibus sodales</a></li>
<li><a href=\"#\">Sed elit nisi</a></li>
<li><a href=\"#\">Suspendisse commodo</a></li>
<li><a href=\"#\">Cras id rutrum leo</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('7','_ID_LANG_','Toshiba','<ul><li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Vivamus porta</a></li>
<li><a href=\"#\">Sed faucibus sodales</a></li>
<li><a href=\"#\">Sed elit nisi</a></li>
<li><a href=\"#\">Suspendisse commodo</a></li>
<li><a href=\"#\">Cras id rutrum leo</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('8','_ID_LANG_','Sony Bravia','<ul><li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Vivamus porta</a></li>
<li><a href=\"#\">Sed faucibus sodales</a></li>
<li><a href=\"#\">Sed elit nisi</a></li>
<li><a href=\"#\">Suspendisse commodo</a></li>
<li><a href=\"#\">Cras id rutrum leo</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('10','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('12','_ID_LANG_','Contact link','<ul><li><a class=\"ybc-mm-item-link\" href=\"http://demo.etssoft.net/digital/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout1\">Contact page 1</a></li>
<li><a class=\"ybc-mm-item-link\" href=\"http://demo.etssoft.net/digital/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout2\">Contact page 2</a></li>
<li><a class=\"ybc-mm-item-link\" href=\"http://demo.etssoft.net/digital/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout3\">Contact page 3</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('13','_ID_LANG_','Cosmetics','<ul><li><a href=\"http://demo.etssoft.net/imake/en/14-lips\">Lips</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/15-skin-care\">Skin Care</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/12-cosmetics\">Cosmetics</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('14','_ID_LANG_','Lorem ipsum','<ul><li><a href=\"http://demo.etssoft.net/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/14-lips\">Lips</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/12-cosmetics\">Cosmetics</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/15-skin-care\">Skin Care</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('15','_ID_LANG_','Lorem ipsum','<ul><li><a href=\"http://demo.etssoft.net/imake/en/12-cosmetics\">Cosmetics</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/15-skin-care\">Skin Care</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/14-lips\">Lips</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('16','_ID_LANG_','Categories','<ul><li><a href=\"http://demo.etssoft.net/imake/en/15-skin-care\">Skin Care</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/18-brows\">Brows</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/14-lips\">Lips</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/12-cosmetics\">Cosmetics</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('17','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('18','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('19','_ID_LANG_','Samsung','<ul><li><a href=\"http://demo.etssoft.net/imake/en/22-headphone\">Headphone</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/20-television\">Television</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/19-mobile-phone\">Mobile phone</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('20','_ID_LANG_','Sony','<ul><li><a href=\"http://demo.etssoft.net/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/22-headphone\">Headphone</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/20-television\">Television</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/19-mobile-phone\">Mobile phone</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('21','_ID_LANG_','Microsoft','<ul><li><a href=\"http://demo.etssoft.net/imake/en/19-mobile-phone\">Mobile phone</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/22-headphone\">Headphone</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/20-television\">Television</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('22','_ID_LANG_','Asus','<ul><li><a href=\"http://demo.etssoft.net/imake/en/21-camera\">Camera</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/19-mobile-phone\">Mobile phone</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/20-television\">Television</a></li>
<li><a href=\"http://demo.etssoft.net/imake/en/22-headphone\">Headphone</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('23','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('24','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('25','_ID_LANG_','Main page','<ul><li><a href=\"http://demo.etssoft.net/digital/blog\">Main page</a></li>
<li><a href=\"http://demo.etssoft.net/digital/en/blog/post/1-sample-post1.html\">Post page</a></li>
<li><a href=\"http://demo.etssoft.net/digital/en/blog/category/1-fashion.html\">Category page</a></li>
<li><a href=\"http://demo.etssoft.net/digital/en/blog/author/1-sang-doan\">Author page</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('26','_ID_LANG_','homepage1','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://demo.etssoft.net/digital/img/cms/ld-home-1.jpg&quot;);\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT1&amp;tc_init=1\"> </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT1&amp;tc_init=1\">Home page 1</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('27','_ID_LANG_','Home page 2','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://demo.etssoft.net/digital/img/cms/ld-home-2.jpg&quot;);\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT2&amp;tc_init=1\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT2&amp;tc_init=1\">Home page 2</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('28','_ID_LANG_','Home page 3','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://demo.etssoft.net/digital/img/cms/ld-home-3.jpg&quot;);\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT3&amp;tc_init=1\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT3&amp;tc_init=1\">Home page 3</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('29','_ID_LANG_','Home page 4','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://demo.etssoft.net/digital/img/cms/ld-home-4.jpg&quot;);\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT4&amp;tc_init=1\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT4&amp;tc_init=1\">Home page 4</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('30','_ID_LANG_','category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('32','_ID_LANG_','Product','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('33','_ID_LANG_','product','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('34','_ID_LANG_','category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('35','_ID_LANG_','category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('36','_ID_LANG_','Hot deals','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('37','_ID_LANG_','html block','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod</p>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('39','_ID_LANG_','Home Page 5','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://demo.etssoft.net/digital/img/cms/ld-home-5.jpg&quot;);\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT5&amp;tc_init=1\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT5&amp;tc_init=1\">Home page 5</a></h4>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('40','_ID_LANG_','Home Page 6','<div class=\"img_homepage\" style=\"background-image:url(&quot;http://demo.etssoft.net/digital/img/cms/ld-home-6.jpg&quot;);\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT6&amp;tc_init=1\">  </a></div>
<h4 class=\"title_menu_homepage\"><a href=\"http://demo.etssoft.net/digital/en/?YBC_TC_LAYOUT=LAYOUT6&amp;tc_init=1\">Home page 6</a></h4>');


