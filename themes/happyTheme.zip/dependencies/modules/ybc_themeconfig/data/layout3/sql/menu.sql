INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('2','CUSTOM','http://demo.etssoft.net/digital/en/3-television','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','fa-television','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('4','CUSTOM','http://demo.etssoft.net/digital/en/6-phones','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','i-mobile.png','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('5','CONTACT','','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','fa-envelope-o','','1','11');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('8','CUSTOM','http://demo.etssoft.net/digital/blog','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','fa-pencil-square-o','','1','12');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('10','CUSTOM','http://demo.etssoft.net/digital/en/5-pc-computer','0','0','0','FULL','100','','','','','','#FFFFFF','title','1','bottom','','','ybc_new','1','','i-computer.png','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('11','CUSTOM','http://demo.etssoft.net/digital/en/4-laptops','0','0','0','FULL','100','','','','','','#FFFFFF','title','1','bottom','','','ybc_sale','1','','i-laptop.png','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('12','CUSTOM','http://demo.etssoft.net/digital/en/7-cameras-lenses','0','0','0','FULL','100','#333333','#777777','','#FF564B','#DDDDDD','#FFFFFF','title','1','bottom','','','','1','fa-camera-retro','','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('13','CUSTOM','http://demo.etssoft.net/digital/en/8-electronics','0','0','0','FULL','100','#333333','#777777','','#FF564B','#DDDDDD','#FFFFFF','title','1','bottom','','','','1','','i-electronic.png','1','7');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('14','CUSTOM','http://demo.etssoft.net/digital/en/9-apples','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','i-apple.png','1','8');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('15','CUSTOM','http://demo.etssoft.net/digital/en/10-smart-watch','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','i-watch.png','1','9');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('16','CUSTOM','http://demo.etssoft.net/digital/en/11-accessories','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','fa-headphones','','1','10');


INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('4','4','HTML','1','1','1','1','model.jpg','1','','','4');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('5','30','HTML','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:0:{}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','1','1','1','','1','','#','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('9','32','PRODUCT','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:0:{}}s:7:\"PRODUCT\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','0','1','1','','1','','','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('11','34','HTML','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:0:{}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','1','1','1','','1','','','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('13','35','HTML','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:0:{}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','1','1','1','','1','','','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('15','36','PRODUCT','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:0:{}}s:7:\"PRODUCT\";a:2:{i:0;s:1:\"4\";i:1;s:1:\"6\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','1','1','1','','1','ybc_hot','','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('16','33','PRODUCT','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:0:{}}s:7:\"PRODUCT\";a:2:{i:0;s:1:\"5\";i:1;s:1:\"6\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','0','1','1','','1','','','1');


INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('6','2','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('7','2','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('8','2','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('10','2','1','','0','0','content_center_midle','3_12','television.jpg','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('12','5','1','','0','1','','12_12','','0','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('13','7','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('14','7','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('15','7','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('16','7','1','','1','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('17','7','1','','0','1','','6_12','hygiene-870763_960_720.jpg','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('18','7','1','','0','1','','6_12','perfume-1433654_960_720.jpg','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('19','9','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('20','9','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('21','9','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('22','9','1','','1','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('23','9','1','','0','1','','6_12','imac-606765_960_720.jpg','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('24','9','1','','0','1','','6_12','laptop-computer-1245981_960_720.jpg','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('25','8','1','','0','1','','12_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('26','1','1','','0','1','','2_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('27','1','1','','0','1','','2_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('28','1','1','','0','1','','2_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('29','1','1','','0','1','','2_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('30','11','1','#','0','0','','3_12','','0','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('32','11','1','','0','0','','4_12','','0','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('33','11','1','','0','0','','4_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('34','10','1','#','0','0','','3_12','','0','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('35','10','1','','0','0','','3_12','','0','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('36','10','1','','0','1','','3_12','','0','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('37','10','1','','0','1','','3_12','ipad.jpg','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('39','1','1','','0','1','','2_12','','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('40','1','1','','0','1','','2_12','','1','6');


