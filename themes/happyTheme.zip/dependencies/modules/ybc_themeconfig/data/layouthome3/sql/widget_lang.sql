INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('14','_ID_LANG_','Top navigation','','<ul>
<li><a href=\"http://theme.yourbestcode.com/probusiness17/content/4-about-us\">About Us</a></li>
<li><a href=\"#\">Company News</a></li>
<li><a href=\"#\">Support</a></li>
<li><a href=\"http://theme.yourbestcode.com/probusiness17/en/blog\">Blog</a></li>
<li><a href=\"http://theme.yourbestcode.com/probusiness17/en/contact-us\">Contact</a>
<ul>
<li><a href=\"http://theme.yourbestcode.com/probusiness17/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=contactlayout1\">Contact 1</a></li>
<li><a href=\"http://theme.yourbestcode.com/probusiness17/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=contactlayout2\">Contact 2</a></li>
<li><a href=\"http://theme.yourbestcode.com/probusiness17/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=contactlayout3\">Contact 3</a></li>
</ul>
</li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('53','_ID_LANG_','Pro Business','','<h4 class=\"ybc-widget-title\"><a href=\"#\">Pro<span class=\"main-color\"> Business</span></a></h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('54','_ID_LANG_','Furniture Store','','<h4 class=\"ybc-widget-title\"><a href=\"#\">Furniture<span class=\"main-color\"> Store</span></a></h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('70','_ID_LANG_','banner top 1','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('71','_ID_LANG_','banner top 2','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('72','_ID_LANG_','Premium Prestashop Theme','','<h4 class=\"ybc-widget-title\"><a href=\"#\">Premium<span class=\"main-color\"> Prestashop</span> Theme</a></h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta</p>');


