INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('14','ybcCustom4','1','0','1','1','','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('53','ybcCustom1','1','0','1','1','banner-home1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('54','ybcCustom3','1','0','1','1','bnsp.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('70','displayTopColumn','1','0','1','1','banner-top1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('71','displayTopColumn','1','0','1','1','banner-top2.jpg','','#','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('72','ybcCustom2','1','0','1','1','banner2.jpg','','#','1');


