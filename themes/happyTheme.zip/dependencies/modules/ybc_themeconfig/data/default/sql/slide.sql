INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('1','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('1','0','1','random','7%','310px','25%','type1','left','left','50%','c2_ls_5','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','0','1','random','7%','310px','10%','type2','left','left','50%','','#');


