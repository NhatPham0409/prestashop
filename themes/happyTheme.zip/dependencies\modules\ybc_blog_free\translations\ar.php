<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>ybc_blog_free_59526bf44608558c7a7331e99f4b8038'] = 'Latest post hebrew';
$_MODULE['<{ybc_blog_free}prestashop>ybc_blog_free_17fe63a5060231fe0c7e84a0528bc7fd'] = 'Featured posts hebrew';
$_MODULE['<{ybc_blog_free}prestashop>ybc_blog_free_3cfd94e5b1e020a2b88c15f49d57886e'] = 'Blog categories hebrew';
$_MODULE['<{ybc_blog_free}prestashop>ybc_blog_free_03904e973e81c46dfc62dcc40779d51e'] = 'Blog gallery hebrew';
$_MODULE['<{ybc_blog_free}prestashop>ybc_blog_free_28ebdaa0a6e32294c89d6bf45d70f7ee'] = 'Blog tag hebew';
$_MODULE['<{ybc_blog_free}prestashop>ybc_blog_free_8f586a6f7d67739f6c83fa1e94a95f0b'] = 'blog search hebrew';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'تعليقات';
$_MODULE['<{ybc_blog_free}prestashop>single_post_7a8dbd683001159655afc3f4935b3fd4'] = 'invio';
$_MODULE['<{ybc_blog_free}prestashop>categories_block_3cfd94e5b1e020a2b88c15f49d57886e'] = 'الفئات';
$_MODULE['<{ybc_blog_free}prestashop>popular_posts_block_0422ae5ca6429121fc69c4eb1c643b32'] = 'Popular posts hebrew';
$_MODULE['<{ybc_blog_free}prestashop>search_block_496d09a4b58f276873f653cbd25f8ced'] = 'Blog Search 12';
